#include<stdio.h>

int main()
{
    char input;
	printf("%s","Enter the character\n");
	scanf("%c",&input);
	printf("The Value entered is %c\n",input);
	printf("The Ascii value of the character is %d \n", input);
    return 0;
}