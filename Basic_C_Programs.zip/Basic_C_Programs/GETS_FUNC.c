#include<stdio.h>

int main()
{
char str[50];
printf("Please Enter the string: \n");
gets(str);
printf("The Input String is: %s \n",str);
}